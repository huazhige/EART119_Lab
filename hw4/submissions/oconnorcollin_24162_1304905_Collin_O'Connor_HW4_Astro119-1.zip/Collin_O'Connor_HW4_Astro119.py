# -*- coding: utf-8 -*-
"""
Created on Thu May  2 18:28:01 2019

@author: colli
"""

import numpy as np
import matplotlib.pyplot as plt
import opt_utils
#==============================================================================
#Homwork 4
#==============================================================================
#==============================================================================
#Problem 2
#==============================================================================
#==============================================================================
#a
#==============================================================================

dPar={'tmin':-10, 'tmax':10,
      't0':2.5, 'c':1.1,
      'A':5}
t=np.linspace(-10, 10, 1000)

def f_t(t):
    return dPar['c']*(t-dPar['t0'])**2

def g_t(t):
    return dPar['A']*t + dPar['t0']

def ht(t):
    return f_t(t)-g_t(t)

y=np.linspace(0,0,1000)

plt.figure(1)
ax=plt.subplot(211)
plt.plot(t, f_t(t), 'r', label='ft(t)')
plt.plot(t, g_t(t), 'b', label='gt(t)')
plt.legend(loc='upper right')
ax.set_xlabel('time[s]')


ax=plt.subplot(212)
ax.plot(t, ht(t), 'b', label='ht(t)')
ax.set_xlabel('time[s]')
ax.set_ylabel('ht(t)')
plt.legend(loc='upper right')
ax.plot(t, y, 'k--', ms=10)

print 'There are two crossover points between the two functions'
#==============================================================================
#b
#==============================================================================

secant1=opt_utils.my_Secant(ht, -10, 10, tol=1e-4, N=20)
print 'crossover point(s) for f(t)-g(t): t =', secant1
print
secant2=opt_utils.my_Secant(ht, -10, 5, tol=1e-4, N=20)
print 'crossover point(s) for f(t)-g(t): t =', secant2

#==============================================================================
#c
#==============================================================================
"""
                            Week 2 assignment method:
"""
tmin, tmax=-10, 10
iN=1000
f_dt=float(tmax-tmin)/(iN-1)

#fn parameters
t0=2.5
c=1.1
A=5
eps=.1 #epsilon


#===============================================================================
#Function def.
#===================================================================
def a_t(t, c, t0):
    return c*(t-t0)**2

def b_t (t, A):
    return A*t+t0


#===============================================================================
#Computations
#==============================================================================
f_curr_t=tmin   #means float for current t(updating time step)
for i in range (iN):
    f_curr_t+=f_dt
    f_curr_f_t=a_t(f_curr_t, c, t0)
    f_curr_g_t=b_t(f_curr_t, A)
    #Fn value comparison
    if abs(f_curr_f_t-f_curr_g_t)<eps:
        print('week 2 method cross over point at t=%.2f, g(t)=%.2f, f(t)=%.2f'%(f_curr_t, f_curr_g_t, f_curr_f_t))

        c_t=np.linspace(tmin, tmax, iN)
#evaluate fn
        a_ft= a_t(c_t, c, t0)
        a_gt= b_t(c_t, A)

        plt.figure(2)
        plt.plot(f_curr_t, f_curr_f_t, 'm*', ms=14, label='wk 2 crossover pt')
        
plt.plot(c_t, a_ft, 'r-', ms=5, label='wk 2 ft')
plt.plot(c_t, a_gt, 'g-', ms=5, label='wk 2 gt')
plt.plot(t, ht(t), 'b-', ms=5, label='ht(t)')
plt.plot(t, y, 'k--')
plt.plot([secant2], [f_t(secant2)], 'y*', ms=14, label='secant crossover pt')
plt.legend(loc='upper right')
plt.show
        

#==============================================================================
#Problem 3
#==============================================================================
def my_Newton( fct, df_dt, x0, tol = 1e-6, N = 20):
    """
    :param fct:     - find root of this fct. closes to x0
    :param dfct_dt: - derivatice of fct
    :param x0:      - initial guess of solution
    :param N:       - number of iterations, default = 20
    :param tol:     - tolerance, default = 1e-4
    :return: f_r0 - closest to x0
    """
    xn = float( x0)
    i  = 0
    while abs( fct( xn)) > tol and i < N: # could also set fct. to ~0 to find root instead of min.
        x_next = xn - fct( xn)/df_dt( xn)
        print i, abs( fct( xn)), x_next
        xn = float( x_next)
        i += 1
        if abs(fct(xn**(i+1))-fct(xn**i))>tol:
            break

    if abs( fct( xn)) > tol:# no solution found
        return None
    else:
        return float( x_next)


#==============================================================================
#Problem 4
#==============================================================================
#==============================================================================
#a
#==============================================================================
def f1(x):
    return -(x**5) + (1/3)*(x**2)+0.5

f_1=opt_utils.my_Secant(f1, -9, 10, tol=1e-4, N=100)
print f_1
#==============================================================================
#b
#==============================================================================
def f2(x):
    return ((np.cos(x))**2)+0.1

x0=-(np.pi)/4
f_2=opt_utils.my_Secant(f2,-9, 10, tol=1e-4, N=50)
print f_2

#==============================================================================
#c
#==============================================================================
def f3(x):
    return np.sin(x/3) + 0.1*(x+5)

f_3=opt_utils.my_Secant(f3,-3, 3, tol=1e-4, N=20)
print f_3


#==============================================================================
#Problem 5
#==============================================================================

vert='HW4_vertTraj.txt'

t,z=np.genfromtxt(vert).T

df_dt=np.zeros(len(t))
d2f_dt2=np.zeros(len(t))

for i in range(1, len(t)-1):
    df_dt[i]=(z[i+1] - z[i-1])/(t[i+1] - t[i-1])
    
for i in range(2, len(t)-2):
    d2f_dt2[i]=(df_dt[i+1] - df_dt[i-1])/(t[i+1] - t[i-1])

plt.figure(3)
ax1=plt.subplot(221)
ax1.plot(t, z, 'r-', label='position')
ax1.set_xlabel('time[s]')
ax1.set_ylabel('position[m]')

ax2=plt.subplot(222)
ax2.plot(t, df_dt, 'b-', label='velocity')
ax2.set_xlabel('time[s]')
ax2.set_ylabel('velocity[m/s]')
plt.legend(loc='upper right')

ax3=plt.subplot(223)
ax3.plot(t, d2f_dt2, 'g-', label='acceleration')
ax3.set_xlabel('time[s]')
ax3.set_ylabel('acceleration[m/s^2]')
plt.legend(loc='upper center')
