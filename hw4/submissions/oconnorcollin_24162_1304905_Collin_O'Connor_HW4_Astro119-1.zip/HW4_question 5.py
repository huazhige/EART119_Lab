# -*- coding: utf-8 -*-
"""
Created on Sun May  5 18:14:34 2019

@author: colli
"""

import numpy as np
import matplotlib.pyplot as plt
import opt_utils
#==============================================================================
#Problem 5
#==============================================================================

vert='HW4_vertTraj.txt'

t,z=np.genfromtxt(vert).T

df_dt=np.zeros(len(t))
d2f_dt2=np.zeros(len(t))

for i in range(1, len(t)-1):
    df_dt[i]=(z[i+1] - z[i-1])/(t[i+1] - t[i-1])
    
for i in range(2, len(t)-2):
    d2f_dt2[i]=(df_dt[i+1] - df_dt[i-1])/(t[i+1] - t[i-1])

plt.figure(3)
ax1=plt.subplot(221)
ax1.plot(t, z, 'r-', label='position')
ax1.set_xlabel('time[s]')
ax1.set_ylabel('position[m]')
plt.legend(loc='lower right')
ax2=plt.subplot(222)
ax2.plot(t, df_dt, 'b-', label='velocity')
ax2.set_xlabel('time[s]')
ax2.set_ylabel('velocity[m/s]')
plt.legend(loc='upper right')

ax3=plt.subplot(223)
ax3.plot(t, d2f_dt2, 'g-', label='acceleration')
ax3.set_xlabel('time[s]')
ax3.set_ylabel('acceleration[m/s^2]')
plt.legend(loc='upper center')

file_out= 'Hw4_5_fixed.png'
plt.savefig( file_out)
plt.show()