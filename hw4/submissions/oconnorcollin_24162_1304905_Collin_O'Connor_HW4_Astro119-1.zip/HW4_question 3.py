# -*- coding: utf-8 -*-
"""
Created on Sun May  5 22:22:56 2019

@author: colli
"""


import numpy as np
import matplotlib.pyplot as plt
import opt_utils
#==============================================================================
#Problem 3
#==============================================================================
def my_Newton( fct, df_dt, x0, tol = 1e-6, N = 20):
    """
    :param fct:     - find root of this fct. closes to x0
    :param dfct_dt: - derivatice of fct
    :param x0:      - initial guess of solution
    :param N:       - number of iterations, default = 20
    :param tol:     - tolerance, default = 1e-4
    :return: f_r0 - closest to x0
    """
    xn = float( x0)
    i  = 0
    while abs( fct( xn)) > tol and i < N: # could also set fct. to ~0 to find root instead of min.
        x_next = xn - fct( xn)/df_dt( xn)
        print i, abs( fct( xn)), x_next
        xn = float( x_next)
        i += 1
        if abs(fct(xn**(i+1))-fct(xn**i))>tol:
            break

    if abs( fct( xn)) > tol:# no solution found
        return None
    else:
        return float( x_next)


dPar={'tmin':-10, 'tmax':10,
      't0':2.5, 'c':1.1,
      'A':5}
t=np.linspace(-10, 10, 1000)

def f_t(t):
    return dPar['c']*(t-dPar['t0'])**2

def g_t(t):
    return dPar['A']*t + dPar['t0']

print my_Newton(f_t, g_t, -9, tol = 1e-6, N = 20)