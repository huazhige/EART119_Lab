#!/bin/python2.7

"""

solve second order, non-homogeneous ODE: undamped harmonic oscillator

- compare analytical and numerical

ODE: my''(t) + gy'(t) + ky(t) = f(t)
        w0**2 = k/m

ana. solution:
    y(t) = F/( (w0**2 - w**2)*( cos(w*t) - cos(w0*t) )
    :TODO - write solution as product of sines
    y(t) = sin * sin

    TODO - compare Euler and Runge-Kutta

"""
from __future__ import division

import os
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np

#-------------------------------0----------------------------------------
#                     fct defintion
#------------------------------------------------------------------------
#import ODE.ode_utils as utils

#:TODO - create a python method that solves the ODE system using Runge-Kutta Method

def num_sol( at, y0, par):
    """
    - solve second order ODE for forced, undamped oscillation by solving two first order ODEs
       ODE:  y''(t) + ky(t) = f(t)
                              f(t) = F*cos(w*t)
    :param y0:         - IC
    :param at  :       - time vector
    :param par :       - dictionary with fct parameters
    :return: ay_hat    - forward Euler
    """
    nSteps    = at.shape[0]
    # create vectors for displacement and velocity
    au_hat    = np.zeros( nSteps)
    av_hat    = np.zeros( at.shape[0])
    #:TODO set the initial conditions
    au_hat[0] = dPar['y01'] # y(0) = 0
    av_hat[0] = dPar['y02'] # y'(0) = 0
    for i in range( nSteps-1):
        # TODO: slope at previous time step, i. RHS of ODE system
        fn1 = av_hat[i]
        fn2 = -par['w']**2*au_hat[i]
        # TODO: -  Euler formula: y[n+1] = y[n] + fn*h
        au_hat[i+1] = au_hat[i] + fn1*par['h']
        av_hat[i+1] = av_hat[i] + fn2*par['h']
        #alternatively use Euler-Cromer: see Langtangen & Linge, p 129, eq: 4.49 - 4.52
        #av_hat[i+1] = av_hat[i] + fn2*par['h']
        #au_hat[i+1] = au_hat[i] + av_hat[i+1]*par['h']
    return au_hat, av_hat
#-------------------------------1----------------------------------------
#                   params, files, dir
#------------------------------------------------------------------------
dPar = {    #frequencies
            'w0' :   .8, #= sqrt(k/m) --> natural frequency
            'w'  :   1, # --> frequency of forcing function
            # forcing function amplitude
            'F'  : 0.5, #20,
            # initial conditions for displ. and velocity
            'y01' : 0, 'y02' : 0,
            # time stepping
            'h'  : 1e-2,
            'tStart' : 0,
            'tStop'  : 30*np.pi,}

## Solving for c1 and c2 (Part b) ##

c1 = -dPar['F'] / (dPar['w0']**2 - dPar['w']**2)
# print(c1) # Unit testing
c2 = ((dPar['F']/(dPar['w0']**2 - dPar['w']**2)) * dPar['w'] *
       np.sin(dPar['w'] * dPar['tStart'])) / dPar['w0']
# print(c2) # Unit testing

#--------------------------------2---------------------------------------
#                      analytical solution
#------------------------------------------------------------------------
at = np.arange( dPar['tStart'], dPar['tStop']+dPar['h'], dPar['h'])
# forcing function
fct_t     = dPar['F']*np.cos( dPar['w']*at)
# TODO: write down the analytical solution
preFacAna = dPar['F']/(dPar['w0']**2 - dPar['w']**2)
ay_ana1   = preFacAna * ( np.cos(dPar['w'] * at) - np.cos(dPar['w0'] * at))
#:TODO rewrite the analytical solution as product of sines (part c)
ay_ana1 = -2 * ( np.sin( (dPar['w'] * at + dPar['w0'] * at)/2.)  * 
                np.sin( dPar['w'] * at - dPar['w0'] * at)/2.)
# envelope - slow frequency
ay_ana2 = -2*preFacAna* ( np.sin( (dPar['w']-dPar['w0'])/2*at))

# Fast frequency

ay_ana3 = -2*preFacAna* ( np.sin( (dPar['w']+dPar['w0'])/2*at))

#--------------------------------3---------------------------------------
#                      numerical solutions
#------------------------------------------------------------------------
aU_num, aV_num = num_sol(  at, [dPar['y01'], dPar['y02']], dPar)

#--------------------------------4---------------------------------------
#                            plots
#------------------------------------------------------------------------
plt.figure(1)
ax = plt.subplot( 111) #plt.axes( [.12, .12, .83, .83])
ax.plot( at, aU_num,   'k-', lw = 3, alpha = .3, label = 'num - displ.')
ax.plot( at,  ay_ana1, 'r--', lw = 1, label = 'ana - full')
ax.plot( at,  ay_ana2,  '--', color = '.5', lw = 2, label = 'ana - env')
ax.plot( at,  -ay_ana2, '--', color = '.5', lw = 2)
ax.plot( at,  ay_ana3,  '--', color = 'green', lw = 2, alpha = .5, label = 'ana - fast')
ax.plot( at,  -ay_ana3, '--', color = 'green', lw = 2, alpha = .5)
ax.plot( at, fct_t, 'b-', lw = 1, alpha = .5, label ='forcing')
ax.set_xlabel( 'Time [s]')
ax.set_ylabel( 'Displacement [mm]')
ax.legend( loc = 'upper left')
plt.show()

#--------------------------------5---------------------------------------
#                        Comparing Solutions
#------------------------------------------------------------------------

# (Part f)

# Forward Euler: u**(n+1) = u**n + (delta)t * f(u**n, t_n)
# Using our variables: y**(n+1) = y**n + h * F(y**n, t_n)



# Fourth-order Runge-Kutta: 
# u**(n+1) = u**n + ((delta)t / 6) * (f**n + 2^f**(n+1/2) + 2~f**(n+1/2) + --f**(n+1))
# Using our variables: 
# y**(n+1) = y**n + (h / 6) * (F**n + 2^F**(n+1/2) + 2~F**(n+1/2) + --F**(n+1))
