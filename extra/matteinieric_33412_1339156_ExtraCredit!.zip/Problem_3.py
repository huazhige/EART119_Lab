"""
Compute the values of the following definite integrals using Monte Carlo Integration. C
ompare your results to the exact solution.
(Hint: For the first integral, you have to perform a coordinate
transform from cartesian to polar coordinates to solve the problem analytically).

f(x,y) = ((x**2) + (y**2))**(1/2); <r r=2

w(x,y) = x * (y**2);  (0 < x < 2)  (0 < y < 1.5)
"""
# import the stuff
import numpy as np
import integrate_utils as iu


# define functions =============================================================


def f_xy( x, y):
    return np.sqrt(x**2 + y**2)

def f_xy2( x, y):
    return x*y**2

def fct_gxy( x, y):

    f_retVal = -1
    if x >= xmin and x <= xmax and y >= ymin and y <= ymax:
        f_retVal = 1
    return f_retVal

def fct2_gxy( x, y):

    f_retVal = -1
    if x >= xmin2 and x <= xmax2 and y >= ymin2 and y <= ymax2:
        f_retVal = 1
    return f_retVal



def int_fxy(theta, r=2):
    return (r**3)*theta /3

def int_fxy2(x,y):
    return  (x**2) * (y**3) / 6

# Define parameters ===========================================================

xmin, xmax = 0, 2
ymin, ymax = 0, 1.5

xmin2, xmax2 = 0, 2
ymin2, ymax2 = 0, 2

a_x = np.linspace( -4, 4, 100)
a_y = np.linspace( -4, 4, 100)


# applying monteCarlo =========================================================


fInt = iu.monteCarlo(f_xy, fct_gxy, xmin - 1, xmax + 1, ymin - 1, ymax + 1, 1000)
f2Int = iu.monteCarlo(f_xy2, fct_gxy, xmin - 1, xmax + 1, ymin - 1, ymax + 1, 1000)

exact_f = int_fxy(2*np.pi) - int_fxy(0)
exact_f2 = int_fxy2(2,1.5) - int_fxy2(0,0)



print("part a.)")
print("MonteCarlo method:%.20f"%fInt)
print("exact:%.20f "%exact_f )

print("part b.)")
print("MonteCarlo method:%.20f"%f2Int)
print("exact:%.20f "%exact_f2 )
