"""
Justin Nguyen
EART119
Extra Credit Problem 1
"""
import numpy as np
import integrate_utils as int_u
#=====================
# functions
#=====================
def fct_t(t):
    return (3*t**2)*np.exp(t**3)

def int_fct_t(t):
    return np.exp(t**3)
#=====================
#computations
#=====================
# integrate fct_t using trapezoid and midpoint methods/formulas
trap_val = int_u.trapezoidal(fct_t, 0, 1, 100)
mid_val = int_u.midpoint(fct_t, 0, 1, 100)

# the exact integral solution
exact_val = int_fct_t(1) - int_fct_t(0)
#=====================
#print results
#=====================

print('The integration of f(t) using the trapezoidal method: ' + str(trap_val))
print('The integration of f(t) using the midpoint method: ' + str(mid_val))
print('The exact integration of f(t): ' + str(exact_val))
"""
Output:
The integration of f(t) using the trapezoidal method: 1.7186215916047791
The integration of f(t) using the midpoint method: 1.7181119551669362
The exact integration of f(t): 1.718281828459045
"""