# -*- coding: utf-8 -*-



import numpy as np


def comp_rate(a_t, k):
    """
    * This function computes the distance decay of a seismic event.
        Input:
            a_T    = TimeVector
            k_win  = window
        Output:
            a_bin  = 
            a_rate = 
        Other Params:
            aS     = 
            s_step = for loop iterator
            i1, i2 = 
    """
    
    aS = np.arange(0, a_t.shape[0]-k, 1)
    a_bin = np.zeros(aS.shape[0])
    a_rate = np.zeros(aS.shape[0])
    iS = 0
    for s_step in aS:
        i1, i2 = s_step, s_step+k
        a_rate = k/(a_t[i2]-a_t[i1])
        a_bin[iS] = 0.5(a_t[i1] + a_t[i2])
        
        iS += 1
    return a_bin, a_rate
