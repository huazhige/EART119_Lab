def rect(b, c):
	print(b*c*1.0)

def triangle(h,b):
	print ((0.5)*b*h)


rect(3,4)

triangle(4,3)	