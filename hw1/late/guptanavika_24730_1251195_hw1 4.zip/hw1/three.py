import math

area = math.pi * (12.6)** 2

print area

#best=1.5*x
#b=int(area/1.5)

x=0

while (1.5*x) <= area:
	x=x+1

print (x-1)
