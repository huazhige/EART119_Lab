r=12.6
a=1.5
b=0
while (a*b)<(3.14*(r**2)):
  b+=1
print b
