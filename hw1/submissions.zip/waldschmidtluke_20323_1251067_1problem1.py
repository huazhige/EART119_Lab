"Python 3.6"
"Problem #1"
"Area functions of rectangle and triangle"

#function 'Arect' computes the area of a rectangle w/ sides 'b' and 'c'
def Arect(b,c):
	A=b*c
	return A
print(Arect(3,4))



#function 'Atri' computes the area of a triangle w/ height 'h' and base 'b'
def Atri(h,b):
	A=0.5*h*b
	return A
print(Atri(3,4))





