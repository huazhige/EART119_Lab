b = input("base Length:") #sets length input as b
c = input ("width length:") #sets width input as c
h_b = input ("height of triangle:") #sets h_b as height of triangle
area_of_rectangle = c*b #width times legth
area_of_triangle = 0.5*h_b*b #height times base times one half
print("area of triangle is", area_of_triangle)
print("area of rectangle is", area_of_rectangle)




