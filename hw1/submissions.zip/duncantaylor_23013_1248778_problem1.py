# problem 1
def rectangle(a,b):
	return a*b

def triangle(b,h):
	return .5*b*h
