# -*- coding: utf-8 -*-

"""
Question 1

Write a program that computes the area of a rectangle (A=bc) and the area of a triangle
(A = 0.5*hbb). The input of your function will be b and c for the rectangle and hb and b
for the triangle

"""

#===================================
##          Variables
#===================================

b = 10
c = 10
h = 10

#===================================
##          Area of rectangle
#===================================

A = b*c
print ("Area of rectangle:", A)

#===================================
##          Area of triangle
#===================================

A = 0.5*h*b
print ("Area of triangle:", A)