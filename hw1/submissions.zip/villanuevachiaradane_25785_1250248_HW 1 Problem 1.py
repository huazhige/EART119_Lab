#!/usr/bin/env python
# coding: utf-8

# In[ ]:


# Function for area of a rectangle
# The arguments include the width (b) and length (c) of the rectangle
def a_rect(b, c):
    # Equation of finding the area of a rectangle
    A = b*c
    
    # Returns the area
    return A

# Function for area of a triangle
# The arguments include the width (b) and height (hb) of the triangle
def a_tri(hb, b):
    # Equation of finding the area of a triangle
    A = 0.5*hb*b
    
    # Returns the area
    return A

