# -*- coding: utf-8 -*-
'''
Cesar Laguna
Python 3.6
'''

'''
# 1
Takes inputs (b, c) and provides output of A (area of a rectangle)
Rectangle = rec
'''

b = int(input('Base (rec) :'))  #input allows for user to input their own data/ numbers
c = int(input('Height (rec) :'))
A_rec = b*c
print ('Area of Rectangle', A_rec)

'''
# 1
For area of a triangle
'''

h0 = int(input('Base (tri) :'))
B  = int(input('Height (tri) :'))
A_tri = 0.5*h0*B
print ('Area of Triangle', A_tri)

