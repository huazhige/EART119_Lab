import numpy

#variables
r = 12.6
a = 1.5
pi = numpy.pi


#area functions
acircle = (pi)*(r**2)

#while loop
i = 1
while acircle > (i*a):
    i += 1

print(i-1)