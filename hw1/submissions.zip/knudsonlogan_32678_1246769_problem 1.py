# -*- coding: utf-8 -*-
"""
*************************************Homework 1*********************************************
    Problem 1:
    Write a program that computes the area of a rectangle (A=bc) and the area of a triangle
    (A = 0.5*hbb). The input of your function will be b and c for the rectangle and hb and b
    for the triangle.
    
Annaconda 2, Python 2.7
"""
#============================================
#               Define Varriables
#============================================

b = 5   #base of the rectangle and triangle
c = 5   #height of the rectangle
hb = 5  #height of the triangle

#============================================
#               Calculation
#============================================
print("Area of Rectangle=%s\nArea of Triangle=%s"%(b*c,.5*b*hb)) #printing and performing the area calculations of triangle and rectangle

