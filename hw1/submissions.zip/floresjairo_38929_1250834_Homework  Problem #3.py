# -*- coding: utf-8 -*-
"""
Created on Sun Apr 14 22:38:40 2019
Jairo Flores
Problem #3
"""

#/////////////Problem #3 ////////////
#circle vs rectangle area

#import libary
 import numpy as np
 #Create and Declare variable
 
#
j = 1
areaC =np.pi * np.square(12.6)
areaR = 0.0

#While looop

while areaR <= areaC:
    areaR = (1.5 * j)
    j += .25
print(j)