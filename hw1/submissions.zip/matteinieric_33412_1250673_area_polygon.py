"""
Astr/Earth-119, Homework-1, problem 2
Finding the area of a polygon using for loop
"""
import numpy as np
#================================================
# (x,y) coordinates =====================================
x_crdnts = np.array([1, 3, 4, 3.5, 2])
y_crdnts = np.array([1, 1, 2, 5, 4])
Ints_x = (0, 1, 2, 3, 4)
Ints_y = (1, 2, 3, 4, 0)

# for loop calculation =====================================
for i in 
