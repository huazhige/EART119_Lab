import matplotlib from matplotlib 
import numpy as np
V_1 = (1,1) 
V_2 = (3,1)
V_3 = (4,2)
V_4 = (3.5,5)
V_5 = (2,4)
A = area_of_polygon

#get number x or y in each v
#set area of ploygon as x_1*y_1
