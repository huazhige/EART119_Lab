# -*- coding: utf-8 -*-
"""
 EART 119 HW 1
 -Functions and Vectors-
 
 
"""

"""
1. Write a program that computes the area of a rectangle (A=bc) and the area of a triangle
    (A = 0.5*hbb). The input of your function will be b and c for the rectangle and hb and b
    for the triangle

"""

# Rectangle with sides b and c 

b = 5 
c = 4 

A_r = b*c

print "The area of a rectangle with sides b = 5 and c = 4 is: " , A_r

# Triangle with height h_b and base b
h_b =  10

A_t = 0.5*h_b*b

print "The area of a trinagle with base b = 5 and height = 10 is: " , A_t







