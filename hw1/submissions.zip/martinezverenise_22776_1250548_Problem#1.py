"""
Problem #1
Computing the area of rectangle and the area of a triangle 

"""
b= int(input('base  '))
c= int(input('hieght  '))   
A = b*c                          #Area of Rectangle
print('Area of Rectangle', A)

##Part B##
h0= int(input('height  '))
b= int(input('base for triangle  '))
A_tri= 0.5*h0*b
print('Area of Triangle', A_tri)

#This function allows you to input any value of b, c, and h to find the area of a triangle and rectangle 

 
