# -*- coding: utf-8 -*-
#Defining the variables
b   = input('Enter the base length: ')
c   = input('Enter the height of the rectangle: ')
h_b = input('Enter the height of the traingle: ')
#The calculations
a_rect = b*c
a_tri  = .5 * b * h_b
#The output
print'Area of rectangle = ', a_rect
print'Area of triangle = ', a_tri