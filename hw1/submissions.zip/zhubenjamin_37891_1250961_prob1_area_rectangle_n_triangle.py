# -*- coding: utf-8 -*-
"""
Created on Apr 11, 2019
Class = Astro/Eart 119
Homework 1 - functions and vectors
Student = Benjamin Zhu (1696575)

"""

#==================================================
#           Problem 1
#==================================================

""" computing areas for a rectangle when given input"""

def A1 (b, c):
    return b*c     #defining the function for rectangle

b = input('what is the length of the rectangle?')   #requesting information
c = input('what is the wideth of the rectangle?')

print A1 (b, c)     #printing out result of area calculation




""" computing areas for a rectangle when given input"""

def A2 (h, b): 
   return 0.5*h*b         #defining the function for triangle

b = input('what is the width of the triangle?')   #requesting information
h = input('what is the height of the triangle?')

print A2 (h, b)     #printing out result of area calculation










