
"""
Jairo Flores 
Homework Set # 1
Problem 1
"""
#Define variables and initiate with user values for rectangle
print("This program calculates the area of rectangle given a length and a width.")
Length = input("What is the length of the rectangle?")
Width = input("What is the width of the rectangle?")
area = Length * Width
print("The area of your rectangle is %s" % area)

#Define variables and initiate with user values for triangle
print("This program calculates the area of triangle given a base and a height.")
Base = input("What is base of the triangle?")
Height = input("What is the height of the triangle?")
areaT = .5*Base*Height
print("The area of your triangle is %r" % areaT)

    





  
    

