# -*- coding: utf-8 -*-
"""
Spyder Editor
Homework 1 ASTR/EART 112
Rafael Nunez
#1
"""
"""
Parameters
"""
Ar = "rectangle area"
b = float(2)     #length of the rectangle
c = float(3)     #height of the rectangle

At = "triangle area"
hb = float(1.5)    #base height of the triangle

"""
Equations
""" 

Ar = b * c
print Ar

At = .5 * hb * b
print At


